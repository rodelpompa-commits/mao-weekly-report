MAO Weekly Report for Windows

Send this file to staff using laptop or desktop:
MAO Weekly Report.exe

How it works:
1. Staff double-click MAO Weekly Report.exe.
2. It opens the reporting system in an app-style Edge or Chrome window.
3. The normal browser address bar is hidden.
4. Staff log in using their assigned password.

Important:
This still needs internet because it loads the online reporting system internally.
If Windows SmartScreen appears, click More info, then Run anyway.

For Android phones, send MAO-Weekly-Report.apk instead.
